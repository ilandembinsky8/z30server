package com.prgguru.jersey;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;








@Path("/search")
public class SearchBook {

	@GET 
	// Path: http://localhost/<appln-folder-name>/search/searchbook
	@Path("/booktitle")
	// Produces JSON as response
	@Produces(MediaType.APPLICATION_JSON) 
	// Query parameters are parameters: http://localhost/<appln-folder-name>/search/booktitle
	public String searchBookTitle(@QueryParam("userId") final int userId, @QueryParam("title")final String title,
											@QueryParam("fromyear")final int fromyear, @QueryParam("toyear")final int toyear) {
		String response = "";
		
		JSONObject book = new JSONObject();
		JSONObject book2 = new JSONObject();
		JSONObject book3 = new JSONObject();
		
		if(userId != 0 && Utitlity.isNotNull(title) ){
		try{
			book.put("ceartor", "Adam Sandler");
			book.put("title", "Life under the rocks");
			book.put("subject", "Biology");
			book.put("recordID", "99985bio");
			book.put("year", "2005");
		
			book2.put("ceartor", "Osho");
			book2.put("title", "Intelligence");
			book2.put("subject", "Life style");
			book2.put("recordID", "78524lifosh");
			book2.put("year", "1998");
		
			book3.put("ceartor", "Lisa");
			book3.put("title", "Peace and Love");
			book3.put("subject", "Life style");
			book3.put("recordID", "1508ddjub");
			book3.put("year", "1923");
		}catch(JSONException e){
			//handle exception
		}
		
		JSONArray list = new JSONArray();
		list.put(book);
//		list.put(book2);
//		list.put(book3);
		
		JSONObject mainObj = new JSONObject();
		
		try{
			mainObj.put("result", new Boolean(true));
			//mainObj.put("list", list);
			response = mainObj.toString();
		}
		catch(JSONException e){
		
		}	
		
		}
		
		else{
			if(userId == 0){
				response = Utitlity.constructJSON("userId", false, "wrong argument");
			}
			else if(!Utitlity.isNotNull(title)){
				response = Utitlity.constructJSON("title", false, "wrong argument");
			}
//			else if(fromyear == 0){
//				response = Utitlity.constructJSON("fromyear", false, "wrong argument");
//			}
//			else{
//				response = Utitlity.constructJSON("toyear", false, "wrong argument");
//			}
			
		}
		
		
		return response;
	}
	
	
	@GET 
	// Path: http://localhost/<appln-folder-name>/search/searchbook
	@Path("/bookauthor")
	// Produces JSON as response
	@Produces(MediaType.APPLICATION_JSON) 
	// Query parameters are parameters: http://localhost/<appln-folder-name>/search/bookauthor
	public String searchBookAuthor(@QueryParam("userId") final int userId, @QueryParam("author")final String author,
											@QueryParam("fromyear")final int fromyear, @QueryParam("toyear")final int toyear) {
		String response = "";
		
		JSONObject book = new JSONObject();
		JSONObject book2 = new JSONObject();
		JSONObject book3 = new JSONObject();
		
		if(userId != 0 && Utitlity.isNotNull(author) ){
		try{
			book.put("ceartor", "Adam Sandler");
			book.put("title", "Life under the rocks");
			book.put("subject", "Biology");
			book.put("recordID", "99985bio");
			book.put("year", "2005");
		
			book2.put("ceartor", "Osho");
			book2.put("title", "Intelligence");
			book2.put("subject", "Life style");
			book2.put("recordID", "78524lifosh");
			book2.put("year", "1998");
		
			book3.put("ceartor", "Lisa");
			book3.put("title", "Peace and Love");
			book3.put("subject", "Life style");
			book3.put("recordID", "1508ddjub");
			book3.put("year", "1923");
		}catch(JSONException e){
			//handle exception
		}
		
		JSONArray list = new JSONArray();
		list.put(book);
		list.put(book2);
		list.put(book3);
		
		JSONObject mainObj = new JSONObject();
		
		try{
			mainObj.put("result", new Boolean(true));
			mainObj.put("list", list);
			mainObj.put("test", new Boolean(true));
			response = mainObj.toString();
		}
		catch(JSONException e){
		
		}	
		
		}
		
		else{
			if(userId == 0){
				response = Utitlity.constructJSON("userId", false, "wrong argument");
			}
			else if(Utitlity.isNotNull(author) == false ){
				response = Utitlity.constructJSON("author", false, "wrong argument");
			}
			
		}
		
		return response;
	}
	
	
	

	
}
