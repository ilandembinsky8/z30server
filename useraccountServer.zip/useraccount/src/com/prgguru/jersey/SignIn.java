package com.prgguru.jersey;

import java.sql.Connection;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
//Path: http://localhost/<appln-folder-name>/login
@Path("/signIn")
public class SignIn {
	// HTTP Get Method
	@GET 
	// Path: http://localhost/<appln-folder-name>/login/dologin
	@Path("/doSignIn")
	// Produces JSON as response
	@Produces(MediaType.APPLICATION_JSON) 
	// Query parameters are parameters: http://localhost/<appln-folder-name>/login/dologin?username=abc&password=xyz
	public String doLogin(@QueryParam("username") String username, @QueryParam("password") String password){
		String response="1" ;
		//ExistQuery Q = new ExistQuery("user",null);
		if(checkCredentials(username, password)){
			DBConnection c=new DBConnection();
			JSONArray js= new JSONArray();
			//response = Q.runLoginSearch(c,username,password);
			return Utitlity.constructJSON("signIn",response);
			
		}
	return Utitlity.constructJSON("signIn",false, "Invalid Input");	
	}
	
	/**
	 * Method to check whether the entered credential is valid
	 * 
	 * @param uname
	 * @param pwd
	 * @return
	 */
	private boolean checkCredentials(String uname, String pwd){
		boolean result = true;
		if(!(Utitlity.isNotNull(uname) && Utitlity.isNotNull(pwd)))
			result = false;
		return result;
	}
	
}
