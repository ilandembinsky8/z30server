package com.prgguru.jersey;
//Change these parameters according to your DB
public class Constants {
	public static String dbClass = "com.mysql.jdbc.Driver";
	public static String dbUrl = "jdbc:mysql://libarab.crbu6i1ygais.eu-central-1.rds.amazonaws.com:3306/libArabDB";
	public static String dbUser = "MasterDB";
	public static String dbPwd = "Master!!";
}
